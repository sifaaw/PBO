import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Membaca input, A adalah bilangan pertama, operator adalah operasi, B adalah bilangan kedua
        System.out.println("masukan operasi bilangan [*, /, +, -]");
        int A = scanner.nextInt();
        String operator = scanner.next();
        int B = scanner.nextInt();
        
        // Hasil perhitungan yang akan dicetak
        int result = 0;

        // Menentukan operasi berdasarkan operator yang diinput
        switch (operator) {
            case "+":
                result = A + B;
                break;
            case "-":
                result = A - B;
                break;
            case "*":
                result = A * B;
                break;
            case "/":
                result = A / B;  // Pembagian dijamin habis
                break;
            case "%":
                result = A % B;
                break;
            default:
                System.out.println("Operator tidak valid");
                return;
        }
        
        // Menampilkan hasil
        System.out.println(result);
        
        scanner.close();
    }
}
