import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        
        System.out.println("masukkan karakter:");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        
        Pattern pattern = Pattern.compile("[A-Za-z]+");
        Matcher matcher = pattern.matcher(input);

        int tokenCount = 0;
        StringBuilder tokens = new StringBuilder();

        while (matcher.find()) {
            tokens.append(matcher.group()).append("\n");
            tokenCount++;
        }
        System.out.println("");
        System.out.println("hasil:");
        System.out.println(tokenCount);
        System.out.print(tokens.toString());
    }
}
