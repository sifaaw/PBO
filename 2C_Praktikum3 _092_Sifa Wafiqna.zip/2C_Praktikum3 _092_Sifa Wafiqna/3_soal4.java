import java.util.Scanner;

public class soal4 {
    public static void main(String[] args) {
        // Membuat Scanner untuk membaca input jumlah penjualan
        Scanner scanner = new Scanner(System.in);
        
        // Membaca input jumlah penjualan
        System.out.print("Masukkan jumlah penjualan: ");
        int jumlahPenjualan = scanner.nextInt();
        
        // Deklarasi variabel
        int gajiPokok = 500000;
        int hargaPerItem = 50000;
        double gajiAkhir = gajiPokok;
        
        // Menghitung total penjualan
        int totalPenjualan = jumlahPenjualan * hargaPerItem;
        
        // Kondisi untuk menghitung bonus atau denda berdasarkan jumlah penjualan
        if (jumlahPenjualan > 80) {
            // Bonus 35% dari total penjualan
            gajiAkhir += 0.35 * totalPenjualan;
        } else if (jumlahPenjualan >= 40) {
            // Bonus 25% dari total penjualan
            gajiAkhir += 0.25 * totalPenjualan;
        } else if (jumlahPenjualan < 15) {
            // Denda 15% dari kekurangan penjualan dari 15 item
            int kekurangan = 15 - jumlahPenjualan;
            gajiAkhir -= 0.15 * (kekurangan * hargaPerItem);
        } else {
            // Bonus 10% dari total penjualan
            gajiAkhir += 0.10 * totalPenjualan;
        }
        
        // Mencetak gaji akhir
        System.out.println((int)gajiAkhir);
        
        // Menutup scanner
        scanner.close();
    }
}