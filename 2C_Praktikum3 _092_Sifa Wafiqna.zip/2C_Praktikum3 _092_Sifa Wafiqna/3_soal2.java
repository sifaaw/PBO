import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Array untuk menyimpan 3 baris input
        String[] inputs = new String[3];
        int[] numbers = new int[3];
        
        System.out.println("masukkan 3 baris nama dan nilainya!");

        // Mengambil input dari user sebanyak 3 baris
        for (int i = 0; i < 3; i++) {
            inputs[i] = scanner.next();  // Baca string
            numbers[i] = scanner.nextInt();  // Baca angka
        }

        // Setelah semua input dimasukkan, tampilkan hasilnya
        System.out.println("================================");
        for (int i = 0; i < 3; i++) {
            // Tampilkan string dengan format
            // %-15s : String rata kiri dengan panjang 15 karakter
            // %03d : Integer dengan panjang 3 digit, tambahkan nol di depan jika kurang dari 3 digit
            System.out.printf("%-15s%03d%n", inputs[i], numbers[i]);
        }
        System.out.println("================================");
    }
}
