import java.math.BigInteger;
import java.util.Scanner;

//penjumlahan angka besar

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Membaca dua angka besar sebagai input
        BigInteger a = new BigInteger(scanner.nextLine());
        BigInteger b = new BigInteger(scanner.nextLine());

        // Melakukan penjumlahan
        BigInteger sum = a.add(b);

        // Melakukan perkalian
        BigInteger product = a.multiply(b);

        // Mencetak hasil
        System.out.println(sum);
        System.out.println(product);

        scanner.close();
    }
}
