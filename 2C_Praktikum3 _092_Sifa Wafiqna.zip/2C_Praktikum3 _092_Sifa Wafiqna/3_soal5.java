import java.util.Scanner;

public class soal5 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari pengguna
        Scanner scanner = new Scanner(System.in);
        
        // Meminta pengguna untuk memasukkan 4 nomor plat mobil
        String plat1 = scanner.next();
        String plat2 = scanner.next();
        String plat3 = scanner.next();
        String plat4 = scanner.next();
        
        // Menggabungkan nomor plat menjadi satu string
        String gabunganPlat = plat1 + plat2 + plat3 + plat4;
        
        // Mengubah string gabungan menjadi bilangan panjang (long)
        long gabunganAngka = Long.parseLong(gabunganPlat);
        
        // Mengecek apakah gabunganAngka habis dibagi 5 setelah dikurangi 999999
        if ((gabunganAngka - 999999) % 5 == 0) {
            System.out.println("Jalan");
        } else {
            System.out.println("Berhenti");
        }
        
        // Menutup scanner
        scanner.close();
    }
}